import pygame
import random
from pygame.draw import circle, lines, rect
from pygame.math import Vector2
from fish_tank_fish import Agent

screen_width = 1280
screen_height = 720

class App:
    def __init__(self):
        print("Application is created")
        pygame.init()
        self.screen = pygame.display.set_mode((screen_width, screen_height))
        pygame.display.set_caption("Fish_tank_Feesh")
        self.clock = pygame.time.Clock()
        self.CHAGE_DIR = pygame.USEREVENT +1
        pygame.time.set_timer(self.CHAGE_DIR, 2000)
        self.running = True
        self.fish_food_position = Vector2(100, -80)
        self.fish_food_space = Vector2(20,0)
        self.barrel_pos = Vector2(screen_width/2 , 50)
        self.beach_pos = Vector2(0, screen_height - 180)
        self.dome_pos = Vector2((screen_width/2) - 232, screen_height - 360)

        self.seaweed_pos = Vector2(120 , screen_height - 250)
        self.seaweed2_pos = Vector2(30 , screen_height - 350)
        self.seaweed_space = Vector2(300, 0)
        self.seaweed2_space = Vector2(250, 0)

        self.clown_fish_run_frequency = 0.05
        self.clown_fish_run_velocity = 6
        self.clown_fish_pos = Vector2(-100, screen_height - 270)
        self.clown_fish_pos_y_initial = screen_height - 270
        self.clown_fish_space = Vector2(-300, 0)
        self.clown_fish_amp = 35

        self.minnow_fish_pos = Vector2(200, (screen_height/2) - 150)
        self.minnow_fish_space = Vector2(100, 15)
        self.hunger_timer = 0

        self.Background = [Agent(position = Vector2(0,0),
                                                radius = 50, color = (84, 84, 84), respawn_pos = Vector2(0,0) )]
        self.Background_beach = [Agent(position = self.beach_pos,
                                                radius = 50, color = (84, 84, 84), respawn_pos = Vector2(0,0) )]
        self.Background_dome = [Agent(position = self.dome_pos,
                                                radius = 50, color = (84, 84, 84), respawn_pos = Vector2(0,0) )]
        self.agents = [
                        Agent(position = self.fish_food_position + (self.fish_food_space * i),
                                                radius = 30, color = (255, 0, 0),
                            respawn_pos = self.fish_food_position + (self.fish_food_space * i)) 
                        
                        for i in range(1, 6)                                         
                                                ]

        self.seaweed = [
                        Agent(position = self.seaweed_pos + (self.seaweed_space * i),
                                                radius = 30, color = (255, 0, 0),) 
                        
                        for i in range(0, 4)                                         
                                                ]
        
        self.seaweed2 = [
                        Agent(position = self.seaweed2_pos + (self.seaweed2_space * i),
                                                radius = 30, color = (255, 0, 0),) 
                        
                        for i in range(0, 5)                                         
                                                ]
        
        self.clown_fish = [
                        Agent(position = self.clown_fish_pos + (self.clown_fish_space * i),
                                                radius = 30, color = (255, 0, 0),) 
                        
                        for i in range(0, 2)                                         
                                                ]
        
        self.minnow_fish = [
                        Agent(position = self.minnow_fish_pos + (self.minnow_fish_space * i),
                                                radius = 30, color = (255, 0, 0),) 
                        
                        for i in range(0, 6)                                         
                                                ]

    
    def handle_input(self):
        for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    self.running = False
                if event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_SPACE:
                        for agent in self.agents:
                            if not agent.moving :
                                agent.respawn_to_barrel(self.barrel_pos)
                                agent.eaten = False
                                break
    
    def update(self, delta_time_ms): 

        for agent in self.agents:    
            if agent.moving and agent.position.y > 0:      
                agent.set_gravity(Vector2(0,2)) 
                force = Vector2(random.randint(-10,10), 0)
                agent.apply_force(force)
                agent.update(delta_time_ms)

                if agent.position.y > self.beach_pos.y + 50:
                    agent.moving = False
                    agent.vel = Vector2(0, 0)
                    agent.acc = Vector2(0, 0)
                    agent.set_gravity(Vector2(0,0))
                    
                    if not agent.eaten:
                        agent.position = agent.respawn_pos
                    else:
                        agent.position = Vector2(-100, -100) 

        self.hunger_timer += 1          

        for agent in self.clown_fish:
            agent.sine_mov(self.clown_fish_run_velocity,self.clown_fish_pos_y_initial, 
                           self.clown_fish_amp, self.clown_fish_run_frequency)
        
        for i, agent in enumerate(self.minnow_fish):
            
            cohesion = agent.get_cohesion_force(self.minnow_fish)
            separation = agent.get_separation_force(self.minnow_fish)
            alignment = agent.get_align_force(self.minnow_fish)
            movement_force = Vector2(random.randint(0,10), random.randint(-10,10))

            agent.apply_force(cohesion)
            agent.apply_force(separation)
            agent.apply_force(alignment)
            agent.apply_force(movement_force)

            if self.hunger_timer > 200:
                nearest_food = min(self.agents, key = lambda f: (f.position - agent.position).length_squared())
                if 0 <= nearest_food.position.x <= screen_width and 0 <= nearest_food.position.y <= self.beach_pos.y:
                    arrive_force = agent.arrive_to(nearest_food.position)
                    agent.apply_force(arrive_force)

                    if (agent.position - nearest_food.position).length_squared() < 20 * 20:
                        self.hunger_timer = 0
                        nearest_food.eaten = True
                        nearest_food.moving = False
                        nearest_food.position = Vector2(-100, -100)

            agent.bound_check(agent)
            agent.update(delta_time_ms)

    def draw(self):
        self.screen.fill("grey")
        self.Background[0].draw_BG(self.screen)
        for agent in self.agents:
            agent.draw(self.screen)

        self.Background_beach[0].draw_BG_beach(self.screen)
        for agent in self.seaweed2:
            agent.draw_seaweed2(self.screen)

        self.Background_dome[0].draw_BG_dome(self.screen)

        for agent in self.clown_fish:    
            if agent.sine_velocity > 0:
                agent.draw_clown_fish(self.screen)
            else:
                agent.draw_clown_fish_flip(self.screen)
        
        for agent in self.minnow_fish:
            if self.hunger_timer < 200:
                if agent.vel.x > 0:
                    agent.draw_minnow_fish_flip(self.screen)
                else:
                    agent.draw_minnow_fish(self.screen)

            else:    
                if agent.vel.x > 0:
                    agent.draw_hungry_minnow_fish_flip(self.screen)
                else:
                    agent.draw_hungry_minnow_fish(self.screen)

        for agent in self.seaweed:
            agent.draw_seaweed(self.screen)

        pygame.display.flip()

    def run(self):
        while self.running:
            delta_time_ms = self.clock.tick(60)
            self.handle_input()
            self.update(delta_time_ms)
            self.draw()
 
        pygame.quit()

def main():
    app = App()
    app.run()

if __name__ == "__main__":
    main()
