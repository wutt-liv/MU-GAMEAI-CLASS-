import pygame
import math
import random
from pygame.draw import circle, rect
from pygame.math import Vector2

class Agent:
    def __init__(self, position, radius, color, respawn_pos = None):
        self.screen_width = 1280
        self.screen_height = 720
        self.radius = radius
        self.cycle_color = color
        self.position = position
        self.vel = Vector2(0,0)
        self.acc = Vector2(0,0)
        self.mass = 1.0
        self.EYE_SIGHT = 250
        self.HIT_DIST = 15
        self.MAX_speed = 300
        self.gravity = Vector2(0,0)
        self.center_of_mass = Vector2(0,0)
        self.sine_velocity = 0
        self.beach_pos = Vector2(0, self.screen_height - 180)
        self.BLACK = (0,0,0)

        self.fish_tank_BG_image = pygame.image.load('fish_tank_BG.png').convert_alpha()
        self.fish_tank_BG_sprite_size = Vector2(1280, 720)
        self.fish_tank_BG_scale = 1.0
        self.fish_tank_BG_animation_list = []
        self.fish_tank_BG_animation_step = 2
        self.fish_tank_BG_frame = 0

        self.beach_image = pygame.image.load('beach.png').convert_alpha()
        self.beach_sprite_size = Vector2(1280, 324)
        self.beach_scale = 1.0
        self.beach_animation_list = []
        self.beach_animation_step = 2
        self.beach_frame = 0

        self.dome_image = pygame.image.load('dome.png').convert_alpha()
        self.dome_sprite_size = Vector2(464, 292)
        self.dome_scale = 1.0
        self.dome_animation_list = []
        self.dome_animation_step = 2
        self.dome_frame = 0

        self.seaweed_image = pygame.image.load('seaweed.png').convert_alpha()
        self.seaweed2_image = pygame.image.load('seaweed2.png').convert_alpha()
        self.seaweed_sprite_size = Vector2(96, 126)
        self.seaweed_scale = 2
        self.seaweed2_scale = 1.8
        self.seaweed_animation_list = []
        self.seaweed2_animation_list = []
        self.seaweed_animation_step = 7
        self.seaweed_last_update = pygame.time.get_ticks()
        self.seaweed2_last_update = pygame.time.get_ticks()
        self.seaweed_animation_cooldown = 250
        self.seaweed_frame = 0
        self.seaweed2_frame = 0
        self.seaweed2_animation_cooldown = 300

        self.fish_food_image = pygame.image.load('fish_food.png').convert_alpha()
        self.fish_food_sprite_size = Vector2(16, 16)
        self.fish_food_scale = 2
        self.fish_food_animation_list = []
        self.fish_food_animation_step = 2
        self.fish_food_frame = 0
        self.respawn_pos = respawn_pos if respawn_pos else Vector2(0, 0)

        self.clown_fish_image = pygame.image.load('Clown_Featherback_color.png').convert_alpha()
        self.clown_fish_scale = 0.5
        self.clown_fish_sprite_size = Vector2(588, 303)
        self.clown_fish_frame = 0
        self.clown_fish_position = position

        self.minnow_fish_image = pygame.image.load('Chula_Minnow_color.png').convert_alpha()
        self.hungry_minnow_fish_image = pygame.image.load('Chula_Minnow_color_hungry.png').convert_alpha()
        self.minnow_fish_sprite_size = Vector2(307, 170)
        self.minnow_fish_scale = 0.3
        self.minnow_fish_animation_list = []
        self.minnow_fish_animation_step = 2
        self.minnow_fish_frame = 0

        self.moving = False
        self.has_hit_target = False
        self.eaten = False

    def get_image(sheet, frame, width, height, scale, colour):
        image = pygame.Surface((width, height)).convert_alpha()
        # add image to surface (image, position, image_area)
        image.blit(sheet, (0, 0), ((frame * width), 0, width, height))
        image = pygame.transform.scale(image, (width * scale, height * scale))
        #Make colour tranparent
        image.set_colorkey(colour)
        return image

    def arrive_to(self, target_pos):
        MAX_FORCE = 30
        Thruster_Pow = 1.1

        d = target_pos - self.position
        dist = d.length() 

        if d.length_squared() == 0:
            return Vector2(0,0)
        
        if dist < self.HIT_DIST:
            return Vector2(0,0)

        elif dist < self.EYE_SIGHT:
            desired = d.normalize() * (self.MAX_speed*Thruster_Pow)
        else:
            desired = d.normalize() * self.MAX_speed

        steering = desired - self.vel 
        if steering.length_squared() > MAX_FORCE * MAX_FORCE: 
            steering.scale_to_length(MAX_FORCE)
        
        return steering
    
    def sine_mov(self, velocity, initial_pos_y, amp, frequency):
        if self.sine_velocity == 0:
            self.sine_velocity = velocity
        
        self.position.x += self.sine_velocity
    
        if self.position.x >= self.screen_width + 500:
            self.sine_velocity = self.sine_velocity * -1
        elif self.position.x <= -500:
            self.sine_velocity = self.sine_velocity * -1

        self.position.y = initial_pos_y + amp * math.sin((self.position.x * frequency)/2)

    def set_gravity(self, gravity):
        self.gravity = gravity
    
    def get_cohesion_force(self, agents):
        count = 0
        center_of_mass = Vector2(0,0)
        for agent in agents:
            dist = (agent.position - self.position).length_squared()
            if 0 < dist < 600 * 600:
                center_of_mass += agent.position
                count += 1
        
        if count > 0:
            center_of_mass /= count

            d = center_of_mass - self.position
            d.scale_to_length(2)

            self.center_of_mass = center_of_mass

            return d
        return Vector2()
    
    def get_separation_force(self, agents):
        s = Vector2()
        count = 0
        for agent in agents:
            dist = (agent.position - self.position).length_squared()
            if dist < 100*100 and dist != 0:
                d = self.position - agent.position
                s += d
                count += 1

        if count > 0:
            s.scale_to_length(2)
            return s
        return Vector2()
    
    def get_align_force(self, agents):
        s = Vector2()
        count = 0
        for agent in agents:
            dist = (agent.position - self.position).length_squared()
            if dist < 500*500 and dist != 0:
                s += agent.vel
                count += 1

        if count > 0 and s != Vector2():
            s /= count
            s.scale_to_length(2)
            return s
        return Vector2()
    
    def bound_check(self, agent):
        if agent.position.x < -30:
            agent.position.x = self.screen_width + 30
        elif agent.position.x > self.screen_width + 30:
            agent.position.x = -20
        if agent.position.y < 0:
            agent.position.y = 0
        elif agent.position.y > self.beach_pos.y:
            agent.position.y = self.beach_pos.y
        
    def apply_force(self, force):
        self.acc += force / self.mass
    
    def update(self, delta_time_ms):
        delta_time = delta_time_ms/1000
        self.vel += (self.acc + self.gravity) 
        
        if self.vel.length_squared() > self.MAX_speed * self.MAX_speed:
            self.vel.scale_to_length(self.MAX_speed)

        self.position += self.vel*delta_time
        self.vel *= 0.95
        self.acc.x = 0
        self.acc.y = 0

    def respawn_to_barrel(self, barrel_pos):
        aim_direction = Vector2(0, 1)  
        self.position = barrel_pos + aim_direction
        self.vel = aim_direction * 150  
        self.acc = Vector2(0, 0)         
        self.gravity = Vector2(0, 0)     
        self.moving = True
        self.has_hit_target = False

    def draw_BG(self,screen):
        fish_tank_BG = Agent.get_image(self.fish_tank_BG_image, self.fish_tank_BG_frame, 
                                     self.fish_tank_BG_sprite_size.x, self.fish_tank_BG_sprite_size.y,
                                     self.fish_tank_BG_scale, self.BLACK)
        
        screen.blit(fish_tank_BG, self.position)

    def draw_BG_beach(self,screen):
        beach = Agent.get_image(self.beach_image, self.beach_frame, 
                                     self.beach_sprite_size.x, self.beach_sprite_size.y,
                                     self.beach_scale, self.BLACK)
        
        screen.blit(beach, self.position)

    def draw_BG_dome(self,screen):
        dome = Agent.get_image(self.dome_image, self.dome_frame, 
                                     self.dome_sprite_size.x, self.dome_sprite_size.y,
                                     self.dome_scale, self.BLACK)
        
        screen.blit(dome, self.position)

    def draw_seaweed(self,screen):
        for x in range(self.seaweed_animation_step):
            self.seaweed_animation_list.append(Agent.get_image(self.seaweed_image,x, self.seaweed_sprite_size.x, 
                                                               self.seaweed_sprite_size.y, self.seaweed_scale, self.BLACK))
        
        seaweed_current_time = pygame.time.get_ticks()
        if seaweed_current_time - self.seaweed_last_update >= self.seaweed_animation_cooldown:
            self.seaweed_frame += 1
            self.seaweed_last_update = seaweed_current_time
        if self.seaweed_frame >= len(self.seaweed_animation_list):
            self.seaweed_frame = 0
        
        screen.blit(self.seaweed_animation_list[self.seaweed_frame], self.position)

    def draw_seaweed2(self,screen):
        for x in range(self.seaweed_animation_step):
            self.seaweed2_animation_list.append(Agent.get_image(self.seaweed2_image,x, self.seaweed_sprite_size.x, 
                                                               self.seaweed_sprite_size.y, self.seaweed2_scale, self.BLACK))
        
        seaweed2_current_time = pygame.time.get_ticks()
        if seaweed2_current_time - self.seaweed2_last_update >= self.seaweed2_animation_cooldown:
            self.seaweed2_frame += 1
            self.seaweed2_last_update = seaweed2_current_time
        if self.seaweed2_frame >= len(self.seaweed2_animation_list):
            self.seaweed2_frame = 0
        
        screen.blit(self.seaweed2_animation_list[self.seaweed2_frame], self.position)

    def draw_clown_fish(self, screen):
        clown_fish = Agent.get_image(self.clown_fish_image, self.clown_fish_frame, 
                                     self.clown_fish_sprite_size.x, self.clown_fish_sprite_size.y,
                                     self.clown_fish_scale, self.BLACK)
        
        screen.blit(clown_fish, self.position)

    def draw_clown_fish_flip(self, screen):
        flip_clown_fish_image = pygame.transform.flip(self.clown_fish_image, True, False)
        flip_clown_fish = Agent.get_image(flip_clown_fish_image, self.clown_fish_frame, 
                                     self.clown_fish_sprite_size.x, self.clown_fish_sprite_size.y,
                                     self.clown_fish_scale, self.BLACK)
        
        screen.blit(flip_clown_fish, self.position)
    
    def draw_minnow_fish(self, screen):
        minnow_fish = Agent.get_image(self.minnow_fish_image, self.minnow_fish_frame, 
                                     self.minnow_fish_sprite_size.x, self.minnow_fish_sprite_size.y,
                                     self.minnow_fish_scale, self.BLACK)
        
        screen.blit(minnow_fish, self.position)
    
    def draw_hungry_minnow_fish(self, screen):
        hungry_minnow_fish = Agent.get_image(self.hungry_minnow_fish_image, self.minnow_fish_frame, 
                                     self.minnow_fish_sprite_size.x, self.minnow_fish_sprite_size.y,
                                     self.minnow_fish_scale, self.BLACK)
        
        screen.blit(hungry_minnow_fish, self.position)
    
    def draw_minnow_fish_flip(self, screen):
        flip_minnow_fish_image = pygame.transform.flip(self.minnow_fish_image, True, False)
        flip_minnow_fish = Agent.get_image(flip_minnow_fish_image, self.minnow_fish_frame, 
                                     self.minnow_fish_sprite_size.x, self.minnow_fish_sprite_size.y,
                                     self.minnow_fish_scale, self.BLACK)
        
        screen.blit(flip_minnow_fish, self.position)
    
    def draw_hungry_minnow_fish_flip(self, screen):
        flip_hungry_minnow_fish_image = pygame.transform.flip(self.hungry_minnow_fish_image, True, False)
        flip_hungry_minnow_fish = Agent.get_image(flip_hungry_minnow_fish_image, self.minnow_fish_frame, 
                                     self.minnow_fish_sprite_size.x, self.minnow_fish_sprite_size.y,
                                     self.minnow_fish_scale, self.BLACK)
        
        screen.blit(flip_hungry_minnow_fish, self.position)

    def draw(self,screen):
        fish_food = Agent.get_image(self.fish_food_image, self.fish_food_frame, 
                                     self.fish_food_sprite_size.x, self.fish_food_sprite_size.y,
                                     self.fish_food_scale, self.BLACK)


        fish_rect = fish_food.get_rect(center = (self.position.x, self.position.y))

        screen.blit(fish_food, fish_rect.topleft)
        
        
        